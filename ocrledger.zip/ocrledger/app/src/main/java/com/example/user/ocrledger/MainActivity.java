package com.example.user.ocrledger;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    myDBhelper myHelper;
    EditText edtdate, edtmoney, edttext, edtdateresult, edtmoneyresult, edttextresult;
    Button buttoninit, buttoninsert, buttonprint;
    SQLiteDatabase sqlDB;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("가계부 관리 DB");

        edtdate = (EditText) findViewById(R.id.edtdate);
        edtmoney = (EditText) findViewById(R.id.edtmoney);
        edttext = (EditText) findViewById(R.id.edttext);
        edtdateresult = (EditText) findViewById(R.id.edtdateresult);
        edtmoneyresult = (EditText) findViewById(R.id.edtmoneyresult);
        edttextresult = (EditText) findViewById(R.id.edttextresult);
        buttoninit = (Button) findViewById(R.id.buttoninit);
        buttoninsert = (Button) findViewById(R.id.buttoninsert);
        buttonprint = (Button) findViewById(R.id.buttonprint);

        myHelper = new myDBhelper(this);
        buttoninit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sqlDB = myHelper.getWritableDatabase();
                myHelper.onUpgrade(sqlDB, 1, 2);
                sqlDB.close();
            }
        });

        buttoninsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sqlDB = myHelper.getWritableDatabase();
                sqlDB.execSQL("INSERT INTO groupTBL VALUES + ( + '"
                        + edtdate.getText().toString() + "' , "
                        + edtmoney.getText().toString() + "' , "
                        + edttext.getText().toString() + ");");
                sqlDB.close();
                Toast.makeText(getApplicationContext(), "입력됨", 0).show();
            }
        });

        buttonprint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sqlDB = myHelper.getReadableDatabase();
                Cursor cursor;
                cursor = sqlDB.rawQuery("SELECT * FROM groupTBL;", null);

                String strdate = "날짜" + "/r/n" + "-----" + "/r/n";
                String strmoney = "금액" + "/r/n" + "-----" + "/r/n";
                String strtext = "사용내역" + "/r/n" + "-----" + "/r/n";

                while (cursor.moveToNext()) {
                    strdate += cursor.getString(0) + "/r/n";
                    strmoney += cursor.getString(1) + "/r/n";
                    strtext += cursor.getString(2) + "/r/n";
                }

                edtdateresult.setText(strdate);
                edtmoneyresult.setText(strmoney);
                edttextresult.setText(strtext);

                cursor.close();
                sqlDB.close();
            }
        });
    }

    public class myDBhelper extends SQLiteOpenHelper {
        public myDBhelper(Context context) {
            super(context, "groupDB", null, 1);
        }
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE groubTBL (gName CHAR(20) PRIMARY KEY, gNumber INTEGER);");
        }
        public void onUpgrade(SQLiteDatabase db, int oldversion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS groupTBL");
            onCreate(db);
        }
    }
}
