# graduation
OCR based smart household ledger
